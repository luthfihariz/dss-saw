{{ Form::open(array('route' => 'route.name', 'method' => 'POST')) }}
	<ul>
		<li>
			{{ Form::label('peserta_id', 'Peserta_id:') }}
			{{ Form::text('peserta_id') }}
		</li>
		<li>
			{{ Form::label('nama_ayah', 'Nama_ayah:') }}
			{{ Form::text('nama_ayah') }}
		</li>
		<li>
			{{ Form::label('nama_ibu', 'Nama_ibu:') }}
			{{ Form::text('nama_ibu') }}
		</li>
		<li>
			{{ Form::label('pend_ayah', 'Pend_ayah:') }}
			{{ Form::text('pend_ayah') }}
		</li>
		<li>
			{{ Form::label('pend_ibu', 'Pend_ibu:') }}
			{{ Form::text('pend_ibu') }}
		</li>
		<li>
			{{ Form::label('pekerjaan_ayah', 'Pekerjaan_ayah:') }}
			{{ Form::text('pekerjaan_ayah') }}
		</li>
		<li>
			{{ Form::label('pekerjaan_ibu', 'Pekerjaan_ibu:') }}
			{{ Form::text('pekerjaan_ibu') }}
		</li>
		<li>
			{{ Form::label('agama_ayah', 'Agama_ayah:') }}
			{{ Form::text('agama_ayah') }}
		</li>
		<li>
			{{ Form::label('agama_ibu', 'Agama_ibu:') }}
			{{ Form::text('agama_ibu') }}
		</li>
		<li>
			{{ Form::label('penghasilan', 'Penghasilan:') }}
			{{ Form::text('penghasilan') }}
		</li>
		<li>
			{{ Form::label('rt', 'Rt:') }}
			{{ Form::text('rt') }}
		</li>
		<li>
			{{ Form::label('rw', 'Rw:') }}
			{{ Form::text('rw') }}
		</li>
		<li>
			{{ Form::label('desa', 'Desa:') }}
			{{ Form::text('desa') }}
		</li>
		<li>
			{{ Form::label('kecamatan', 'Kecamatan:') }}
			{{ Form::text('kecamatan') }}
		</li>
		<li>
			{{ Form::label('kab_kota', 'Kab_kota:') }}
			{{ Form::text('kab_kota') }}
		</li>
		<li>
			{{ Form::label('no_hp', 'No_hp:') }}
			{{ Form::text('no_hp') }}
		</li>
		<li>
			{{ Form::submit() }}
		</li>
	</ul>
{{ Form::close() }}