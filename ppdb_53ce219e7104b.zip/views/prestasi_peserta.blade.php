{{ Form::open(array('route' => 'route.name', 'method' => 'POST')) }}
	<ul>
		<li>
			{{ Form::label('peserta_id', 'Peserta_id:') }}
			{{ Form::text('peserta_id') }}
		</li>
		<li>
			{{ Form::label('jenis', 'Jenis:') }}
			{{ Form::text('jenis') }}
		</li>
		<li>
			{{ Form::label('tingkat', 'Tingkat:') }}
			{{ Form::text('tingkat') }}
		</li>
		<li>
			{{ Form::label('jumlah', 'Jumlah:') }}
			{{ Form::text('jumlah') }}
		</li>
		<li>
			{{ Form::submit() }}
		</li>
	</ul>
{{ Form::close() }}