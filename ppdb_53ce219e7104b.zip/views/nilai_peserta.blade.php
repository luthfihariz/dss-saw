{{ Form::open(array('route' => 'route.name', 'method' => 'POST')) }}
	<ul>
		<li>
			{{ Form::label('mapel_id', 'Mapel_id:') }}
			{{ Form::text('mapel_id') }}
		</li>
		<li>
			{{ Form::label('kelas', 'Kelas:') }}
			{{ Form::text('kelas') }}
		</li>
		<li>
			{{ Form::label('semester', 'Semester:') }}
			{{ Form::text('semester') }}
		</li>
		<li>
			{{ Form::label('nilai', 'Nilai:') }}
			{{ Form::text('nilai') }}
		</li>
		<li>
			{{ Form::submit() }}
		</li>
	</ul>
{{ Form::close() }}