{{ Form::open(array('route' => 'route.name', 'method' => 'POST')) }}
	<ul>
		<li>
			{{ Form::label('peserta_id', 'Peserta_id:') }}
			{{ Form::text('peserta_id') }}
		</li>
		<li>
			{{ Form::label('nilai', 'Nilai:') }}
			{{ Form::text('nilai') }}
		</li>
		<li>
			{{ Form::submit() }}
		</li>
	</ul>
{{ Form::close() }}