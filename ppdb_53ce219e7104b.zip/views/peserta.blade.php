{{ Form::open(array('route' => 'route.name', 'method' => 'POST')) }}
	<ul>
		<li>
			{{ Form::label('nama', 'Nama:') }}
			{{ Form::text('nama') }}
		</li>
		<li>
			{{ Form::label('agama', 'Agama:') }}
			{{ Form::text('agama') }}
		</li>
		<li>
			{{ Form::label('ttl', 'Ttl:') }}
			{{ Form::text('ttl') }}
		</li>
		<li>
			{{ Form::label('anak_ke', 'Anak_ke:') }}
			{{ Form::text('anak_ke') }}
		</li>
		<li>
			{{ Form::label('jumlah_saudara', 'Jumlah_saudara:') }}
			{{ Form::text('jumlah_saudara') }}
		</li>
		<li>
			{{ Form::label('jenis_kelamin', 'Jenis_kelamin:') }}
			{{ Form::text('jenis_kelamin') }}
		</li>
		<li>
			{{ Form::label('rt', 'Rt:') }}
			{{ Form::text('rt') }}
		</li>
		<li>
			{{ Form::label('rw', 'Rw:') }}
			{{ Form::text('rw') }}
		</li>
		<li>
			{{ Form::label('desa', 'Desa:') }}
			{{ Form::text('desa') }}
		</li>
		<li>
			{{ Form::label('kecamatan', 'Kecamatan:') }}
			{{ Form::text('kecamatan') }}
		</li>
		<li>
			{{ Form::label('kab_kota', 'Kab_kota:') }}
			{{ Form::text('kab_kota') }}
		</li>
		<li>
			{{ Form::label('nama_sekolah_asal', 'Nama_sekolah_asal:') }}
			{{ Form::text('nama_sekolah_asal') }}
		</li>
		<li>
			{{ Form::label('alamat_sekolah_asal', 'Alamat_sekolah_asal:') }}
			{{ Form::text('alamat_sekolah_asal') }}
		</li>
		<li>
			{{ Form::label('nisn_sekolah_asal', 'Nisn_sekolah_asal:') }}
			{{ Form::text('nisn_sekolah_asal') }}
		</li>
		<li>
			{{ Form::submit() }}
		</li>
	</ul>
{{ Form::close() }}