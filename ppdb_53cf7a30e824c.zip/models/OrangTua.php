<?php

class OrangTua extends Eloquent {

	protected $table = 'orang_tua';
	public $timestamps = false;

	public function orang_tua()
	{
		return $this->hasOne('OrangTua', 'peserta_id');
	}

	public function peserta()
	{
		return $this->belongsTo('Peserta', 'peserta_id');
	}

}