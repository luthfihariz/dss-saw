<?php

class HasilWawancara extends Eloquent {

	protected $table = 'hasil_wawancara';
	public $timestamps = true;

}