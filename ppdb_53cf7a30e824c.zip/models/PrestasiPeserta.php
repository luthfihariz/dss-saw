<?php

class PrestasiPeserta extends Eloquent {

	protected $table = 'prestasi_peserta';
	public $timestamps = false;

}