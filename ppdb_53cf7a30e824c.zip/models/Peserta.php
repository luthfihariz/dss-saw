<?php

class Peserta extends Eloquent {

	protected $table = 'peserta';
	public $timestamps = true;

	public function orang_tua()
	{
		return $this->hasOne('OrangTua', 'peserta_id');
	}

}