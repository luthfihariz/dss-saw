<?php

class MataPelajaran extends Eloquent {

	protected $table = 'mata_pelajaran';
	public $timestamps = false;

	public function mapel()
	{
		return $this->hasMany('MataPelajaran', 'mapel_id');
	}

}