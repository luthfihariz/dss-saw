<?php

class HasilTest extends Eloquent {

	protected $table = 'hasil_test';
	public $timestamps = true;

}